from flask import Blueprint
from __init__ import create_app, db
from flask import Blueprint, render_template
from flask_login import login_required, current_user
import datetime

main = Blueprint('main', __name__)

@main.route('/')
def index():
    db.create_all(app=create_app())
    return render_template('index.html')

@main.route('/profile') #
@login_required
def profile():
    return render_template('profile.html', name=current_user.name, last_login =datetime.datetime.strftime( current_user.last_login,%B%M), phone_number = current_user.phone_number) # name se trimite prin acea variabila

if __name__ == '__main__':
    create_app().run(debug=True)