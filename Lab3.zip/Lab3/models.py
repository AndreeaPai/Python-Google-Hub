from flask_login import UserMixin
from __init__ import db


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True) # primary keys are required by SQLAlchemy
    email = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(100))
    name = db.Column(db.String(1000))
    last_login = db.Column(db.DateTime)
    phone_number = db.Column(db.Integer)


class Location( db.Model):
    id = db.Column(db.Integer, primary_key=True)
    country = db.Column(db.String(100), unique=True)
    companies = db.relationship('Company', backref='location', lazy=True) # adaugam fk din word ?


class Company(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(1000))
    website = db.Column(db.String(1000))
    logo = db.Column(db.String(1000))
    location_id = db.Column(db.Integer, db.ForeignKey('location.id'))  # foreign key ?
    jobs = db.relationship('Job', backref='company', lazy=True) # adaugam fk din word ?


class Job(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.Integer)
    url = db.Column(db.String(1000))
    title = db.Column(db.String(1000))
    description = db.Column(db.Text) # text
    how_to_apply = db.Column(db.Text) # text
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'))

#class Toate(UserMixin, db.Model):
  #  toateUser = User.query.all()
   # return ()

#users = User.query.all()

#for user in users:
   # print (user.id)