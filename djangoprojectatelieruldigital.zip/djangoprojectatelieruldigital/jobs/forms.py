from django import forms
from django.forms import TextInput, Select

from jobs.models import Jobs


class JobsForm(forms.ModelForm):
    class Meta:
        model = Jobs
        fields = ['type', 'url','title','description','how_to_apply','company']

        widgets = {
            'type': TextInput(attrs={'placeholder': 'Type', 'class': 'field'}),
            'url': TextInput(attrs={'placeholder': 'Url', 'class': 'field'}),
            'title': TextInput(attrs={'placeholder': 'Title', 'class': 'field'}),
            'description': TextInput(attrs={'placeholder': 'Description', 'class': 'field'}),
            'how_to_apply': TextInput(attrs={'placeholder': 'How to apply', 'class': 'field'}),
            'company': TextInput(attrs={'placeholder': 'Company', 'class': 'field'})
        }

