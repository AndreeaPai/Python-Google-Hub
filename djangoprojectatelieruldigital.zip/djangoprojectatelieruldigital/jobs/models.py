from django.db import models

# Create your models here.
from companies.models import Companies


class Jobs(models.Model):
    # ID SE IA AUTOMAT ,NU TREBUIE SAL SCRI
    type = models.CharField('Your job', max_length=200)
    url = models.CharField('Your website', null=True, blank=True, max_length=200)
    title = models.CharField('Your title', max_length=200)
    description = models.CharField('Your description', max_length=200)
    how_to_apply = models.CharField('apply', max_length=200)
    company =  models.ForeignKey(Companies, on_delete=models.ForeignKey)