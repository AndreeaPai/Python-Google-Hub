# Create your views here.

from django.urls import reverse
from django.views.generic import CreateView
from django.views.generic import DeleteView
from django.views.generic import ListView
from django.views.generic import UpdateView

from jobs.models import Jobs

from jobs.forms import JobsForm


class JobsIndex(ListView): # resolve unmark reference
    model = Jobs # resolve unmark reference
    context_object_name = 'all_jobs'
    template_name = 'jobs/jobs_index.html'

class CreateJobView(CreateView):
    model = Jobs
    template_name = 'jobs/jobs_form.html'
    form_class = JobsForm

    def get_success_url(self):
        return reverse('jobs:index')

class UpdateJobView(UpdateView):
    model = Jobs
    template_name = 'jobs/jobs_form.html'
    form_class = JobsForm

    def get_success_url(self):
        return reverse('jobs:jobs_company', args=[self.object.id])

class DeleteJobView(DeleteView):
    model = Jobs
    template_name = 'jobs/jobs_form.html'
    form_class = JobsForm

    def get_success_url(self):
        return reverse('company:index')
