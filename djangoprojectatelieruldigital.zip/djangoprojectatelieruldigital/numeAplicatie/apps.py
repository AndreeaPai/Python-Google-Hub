from django.apps import AppConfig


class NumeaplicatieConfig(AppConfig):
    name = 'numeAplicatie'
